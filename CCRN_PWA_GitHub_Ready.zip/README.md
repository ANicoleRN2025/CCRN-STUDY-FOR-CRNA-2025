
# CCRN Dual Scoring Tool (Installable PWA)

This is an offline-capable Progressive Web App that bundles both CCRN scoring tools:
- **Weak-Domain Focus** (preloaded key & pilots)
- **AACN Balanced** (preloaded key & pilots)

## Quick Start (GitHub Pages)
1. Create a new public repo, e.g. `ccrn-scoring-app`
2. Upload these files to the root of the repo:
   - `index.html`
   - `manifest.webmanifest`
   - `sw.js`
   - `favicon.ico`
   - `CCRN_AppIcon_Custom_192.png`
   - `CCRN_AppIcon_Custom_512.png`
   - `apple-splash-2048x2732.png`
3. Go to **Settings → Pages** → set:
   - **Branch**: `main`
   - **Folder**: `/ (root)`
4. After it builds, open the displayed URL (e.g., `https://<your-username>.github.io/ccrn-scoring-app/`).

## Install on iPhone/iPad
- Open the site in **Safari**
- Tap **Share → Add to Home Screen**
- Launch from the Home Screen; app works **offline** after first load

## Notes
- If you update the app, visit the site and **pull to refresh** (or close and reopen) to update the cache.
- The preloaded keys and pilot lists live in the HTML. You can change them later and re-upload.
